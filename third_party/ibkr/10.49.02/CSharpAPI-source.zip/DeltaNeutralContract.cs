/*
 * C# TWS API Client
 *
 * Copyright (C) 2013-2026  Interactive Brokers LLC
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

namespace IBApi
{
    /**
    * @brief Delta-Neutral Contract.
    */
    public class DeltaNeutralContract
    {
        /**
         * @brief The unique contract identifier specifying the security. Used for Delta-Neutral Combo contracts.
         */
        public int ConId { get; set; }

        /**
        * @brief The underlying stock or future delta. Used for Delta-Neutral Combo contracts.
        */
        public double Delta { get; set; }

        /**
        * @brief The price of the underlying. Used for Delta-Neutral Combo contracts.
        */
        public double Price { get; set; }
    }
}
