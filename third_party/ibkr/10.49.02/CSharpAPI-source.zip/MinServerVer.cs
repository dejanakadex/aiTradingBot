/*
 * C# TWS API Client
 *
 * Copyright (C) 2013-2026  Interactive Brokers LLC
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

namespace IBApi
{
    public class MinServerVer
    {
        public const int MIN_VERSION = 38;

        //shouldn't these all be deprecated?
        public const int HISTORICAL_DATA = 24;
        public const int CURRENT_TIME = 33;
        public const int REAL_TIME_BARS = 34;
        public const int SCALE_ORDERS = 35;
        public const int SNAPSHOT_MKT_DATA = 35;
        public const int SSHORT_COMBO_LEGS = 35;
        public const int WHAT_IF_ORDERS = 36;
        public const int CONTRACT_CONID = 37;

        public const int PTA_ORDERS = 39;
        public const int DELTA_NEUTRAL = 40;
        public const int CONTRACT_DATA_CHAIN = 40;
        public const int SCALE_ORDERS2 = 40;
        public const int ALGO_ORDERS = 41;
        public const int EXECUTION_DATA_CHAIN = 42;
        public const int NOT_HELD = 44;
        public const int SEC_ID_TYPE = 45;
        public const int PLACE_ORDER_CONID = 46;
        public const int REQ_MKT_DATA_CONID = 47;
        public const int REQ_CALC_IMPLIED_VOLAT = 49;
        public const int REQ_CALC_OPTION_PRICE = 50;
        public const int CANCEL_CALC_IMPLIED_VOLAT = 50;
        public const int CANCEL_CALC_OPTION_PRICE = 50;
        public const int SSHORTX_OLD = 51;
        public const int SSHORTX = 52;
        public const int REQ_GLOBAL_CANCEL = 53;
        public const int HEDGE_ORDERS = 54;
        public const int REQ_MARKET_DATA_TYPE = 55;
        public const int OPT_OUT_SMART_ROUTING = 56;
        public const int SMART_COMBO_ROUTING_PARAMS = 57;
        public const int DELTA_NEUTRAL_CONID = 58;
        public const int SCALE_ORDERS3 = 60;
        public const int ORDER_COMBO_LEGS_PRICE = 61;
        public const int TRAILING_PERCENT = 62;
        public const int DELTA_NEUTRAL_OPEN_CLOSE = 66;
        public const int ACCT_SUMMARY = 67;
        public const int TRADING_CLASS = 68;
        public const int SCALE_TABLE = 69;
        public const int LINKING = 70;
        public const int ALGO_ID = 71;
        public const int OPTIONAL_CAPABILITIES = 72;
        public const int ORDER_SOLICITED = 73;
        public const int LINKING_AUTH = 74;
        public const int PRIMARYEXCH = 75;
        public const int RANDOMIZE_SIZE_AND_PRICE = 76;
        public const int FRACTIONAL_POSITIONS = 101;
        public const int PEGGED_TO_BENCHMARK = 102;
        public const int MODELS_SUPPORT = 103;
        public const int SEC_DEF_OPT_PARAMS_REQ = 104;
        public const int EXT_OPERATOR = 105;
        public const int SOFT_DOLLAR_TIER = 106;
        public const int REQ_FAMILY_CODES = 107;
        public const int REQ_MATCHING_SYMBOLS = 108;
        public const int PAST_LIMIT = 109;
        public const int MD_SIZE_MULTIPLIER = 110;
        public const int CASH_QTY = 111;
        public const int REQ_MKT_DEPTH_EXCHANGES = 112;
        public const int TICK_NEWS = 113;
        public const int SMART_COMPONENTS = 114;
        public const int REQ_NEWS_PROVIDERS = 115;
        public const int REQ_NEWS_ARTICLE = 116;
        public const int REQ_HISTORICAL_NEWS = 117;
        public const int REQ_HEAD_TIMESTAMP = 118;
        public const int REQ_HISTOGRAM_DATA = 119;
        public const int SERVICE_DATA_TYPE = 120;
        public const int AGG_GROUP = 121;
        public const int UNDERLYING_INFO = 122;
        public const int CANCEL_HEADTIMESTAMP = 123;
        public const int SYNT_REALTIME_BARS = 124;
        public const int CFD_REROUTE = 125;
        public const int MARKET_RULES = 126;
        public const int PNL = 127;
        public const int NEWS_QUERY_ORIGINS = 128;
        public const int UNREALIZED_PNL = 129;
        public const int HISTORICAL_TICKS = 130;
        public const int MARKET_CAP_PRICE = 131;
        public const int PRE_OPEN_BID_ASK = 132;
        public const int REAL_EXPIRATION_DATE = 134;
        public const int REALIZED_PNL = 135;
        public const int LAST_LIQUIDITY = 136;
        public const int TICK_BY_TICK = 137;
        public const int DECISION_MAKER = 138;
        public const int MIFID_EXECUTION = 139;
        public const int TICK_BY_TICK_IGNORE_SIZE = 140;
        public const int AUTO_PRICE_FOR_HEDGE = 141;
        public const int WHAT_IF_EXT_FIELDS = 142;
        public const int SCANNER_GENERIC_OPTS = 143;
        public const int API_BIND_ORDER = 144;
        public const int ORDER_CONTAINER = 145;
        public const int SMART_DEPTH = 146;
        public const int REMOVE_NULL_ALL_CASTING = 147;
        public const int D_PEG_ORDERS = 148;
        public const int MKT_DEPTH_PRIM_EXCHANGE = 149;
        public const int COMPLETED_ORDERS = 150;
        public const int PRICE_MGMT_ALGO = 151;
        public const int STOCK_TYPE = 152;
        public const int ENCODE_MSG_ASCII7 = 153;
        public const int SEND_ALL_FAMILY_CODES = 154;
        public const int NO_DEFAULT_OPEN_CLOSE = 155;
        public const int PRICE_BASED_VOLATILITY = 156;
        public const int REPLACE_FA_END = 157;
        public const int DURATION = 158;
        public const int MARKET_DATA_IN_SHARES = 159;
        public const int POST_TO_ATS = 160;
        public const int WSHE_CALENDAR = 161;
        public const int AUTO_CANCEL_PARENT = 162;
        public const int FRACTIONAL_SIZE_SUPPORT = 163;
        public const int SIZE_RULES = 164;
        public const int HISTORICAL_SCHEDULE = 165;
        public const int ADVANCED_ORDER_REJECT = 166;
        public const int USER_INFO = 167;
        public const int CRYPTO_AGGREGATED_TRADES = 168;
        public const int MANUAL_ORDER_TIME = 169;
        public const int PEGBEST_PEGMID_OFFSETS = 170;
        public const int MIN_SERVER_VER_WSH_EVENT_DATA_FILTERS = 171;
        public const int MIN_SERVER_VER_IPO_PRICES = 172;
        public const int MIN_SERVER_VER_WSH_EVENT_DATA_FILTERS_DATE = 173;
        public const int MIN_SERVER_VER_INSTRUMENT_TIMEZONE = 174;
        public const int MIN_SERVER_VER_HMDS_MARKET_DATA_IN_SHARES = 175;
        public const int MIN_SERVER_VER_BOND_ISSUERID = 176;
        public const int MIN_SERVER_VER_FA_PROFILE_DESUPPORT = 177;
        public const int MIN_SERVER_VER_PENDING_PRICE_REVISION = 178;
        public const int MIN_SERVER_VER_FUND_DATA_FIELDS = 179;
        public const int MIN_SERVER_VER_MANUAL_ORDER_TIME_EXERCISE_OPTIONS = 180;
        public const int MIN_SERVER_VER_OPEN_ORDER_AD_STRATEGY = 181;
        public const int MIN_SERVER_VER_LAST_TRADE_DATE = 182;
        public const int MIN_SERVER_VER_CUSTOMER_ACCOUNT = 183;
        public const int MIN_SERVER_VER_PROFESSIONAL_CUSTOMER = 184;
        public const int MIN_SERVER_VER_BOND_ACCRUED_INTEREST = 185;
        public const int MIN_SERVER_VER_INELIGIBILITY_REASONS = 186;
        public const int MIN_SERVER_VER_RFQ_FIELDS = 187;
        public const int MIN_SERVER_VER_BOND_TRADING_HOURS = 188;
        public const int MIN_SERVER_VER_INCLUDE_OVERNIGHT = 189;
        public const int MIN_SERVER_VER_UNDO_RFQ_FIELDS = 190;
        public const int MIN_SERVER_VER_PERM_ID_AS_LONG = 191;
        public const int MIN_SERVER_VER_CME_TAGGING_FIELDS = 192;
        public const int MIN_SERVER_VER_CME_TAGGING_FIELDS_IN_OPEN_ORDER = 193;
        public const int MIN_SERVER_VER_ERROR_TIME = 194;
        public const int MIN_SERVER_VER_FULL_ORDER_PREVIEW_FIELDS = 195;
        public const int MIN_SERVER_VER_HISTORICAL_DATA_END = 196;
        public const int MIN_SERVER_VER_CURRENT_TIME_IN_MILLIS = 197;
        public const int MIN_SERVER_VER_SUBMITTER = 198;
        public const int MIN_SERVER_VER_IMBALANCE_ONLY = 199;
        public const int MIN_SERVER_VER_PARAMETRIZED_DAYS_OF_EXECUTIONS = 200;
        public const int MIN_SERVER_VER_PROTOBUF = 201;
        public const int MIN_SERVER_ZERO_STRIKE = 202;
        public const int MIN_SERVER_VER_PROTOBUF_PLACE_ORDER = 203;
        public const int MIN_SERVER_VER_PROTOBUF_COMPLETED_ORDER = 204;
        public const int MIN_SERVER_VER_PROTOBUF_CONTRACT_DATA = 205;
        public const int MIN_SERVER_VER_PROTOBUF_MARKET_DATA = 206;
        public const int MIN_SERVER_VER_PROTOBUF_ACCOUNTS_POSITIONS = 207;
        public const int MIN_SERVER_VER_PROTOBUF_HISTORICAL_DATA = 208;
        public const int MIN_SERVER_VER_PROTOBUF_NEWS_DATA = 209;
        public const int MIN_SERVER_VER_PROTOBUF_SCAN_DATA = 210;
        public const int MIN_SERVER_VER_PROTOBUF_REST_MESSAGES_1 = 211;
        public const int MIN_SERVER_VER_PROTOBUF_REST_MESSAGES_2 = 212;
        public const int MIN_SERVER_VER_PROTOBUF_REST_MESSAGES_3 = 213;
        public const int MIN_SERVER_VER_ADD_Z_SUFFIX_TO_UTC_DATE_TIME = 214;
        public const int MIN_SERVER_VER_CANCEL_CONTRACT_DATA = 215;
        public const int MIN_SERVER_VER_ADDITIONAL_ORDER_PARAMS_1 = 216;
        public const int MIN_SERVER_VER_ADDITIONAL_ORDER_PARAMS_2 = 217;
        public const int MIN_SERVER_VER_ATTACHED_ORDERS = 218;
        public const int MIN_SERVER_VER_CONFIG = 219;
        public const int MIN_SERVER_VER_MARKET_DATA_VOLUMES_IN_SHARES = 220;
        public const int MIN_SERVER_VER_UPDATE_CONFIG = 221;
        public const int MIN_SERVER_VER_FRACTIONAL_LAST_SIZE = 222;
        public const int MIN_SERVER_VER_HEDGE_MAX_SIZE = 223;
        public const int MIN_SERVER_VER_USE_PRECISION_FROM_SEC_DEF = 224;
        public const int MIN_SERVER_VER_ODD_LOT_BID_ASK_QUOTES = 225;
    }
}
